// Isi API_URL dengan URL Web App Apps Script (berakhiran /exec) setelah deploy backend.
// File ini boleh publik: tidak berisi rahasia apa pun.
window.HJ_CONFIG = {
  API_URL: "",
  APP_NAME: "HADIR JAMA'AH"
};
